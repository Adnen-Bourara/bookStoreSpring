package com.esprit.project.repositories;

public interface CommentaireRepository {

}
