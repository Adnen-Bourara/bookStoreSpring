package com.esprit.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MagazineRepository extends JpaRepository {

}
