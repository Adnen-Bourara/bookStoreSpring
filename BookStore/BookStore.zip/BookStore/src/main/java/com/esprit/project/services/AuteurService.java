package com.esprit.project.services;

public interface AuteurService {

}
