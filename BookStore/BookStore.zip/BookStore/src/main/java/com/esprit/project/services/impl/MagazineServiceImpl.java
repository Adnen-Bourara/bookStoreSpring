package com.esprit.project.services.impl;

import com.esprit.project.entities.Magazine;
import com.esprit.project.repositories.MagazineRepository;
import com.esprit.project.services.MagazineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MagazineServiceImpl implements MagazineService {
    final MagazineRepository magazineRepository;
    @Autowired
    public MagazineServiceImpl(MagazineRepository magazineRepository) {
        this.magazineRepository = magazineRepository;
    }


    @Override
    public Magazine findById(Long id) {
        return magazineRepository.findById(id).orElse(null);
    }

    @Override
    public List<Magazine> findAll() {
        return magazineRepository.findAll();
    }
}
